package com.rbs.everydaybanking.atf.soapclient;

//import https.www_w3schools_com.xml.CelsiusToFahrenheit;
import org.eclipse.persistence.dynamic.DynamicEntity;
import org.eclipse.persistence.jaxb.dynamic.DynamicJAXBContext;
import org.eclipse.persistence.jaxb.JAXBContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.w3c.dom.Document;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

//@SpringBootApplication
public class EdbAtfSoapClientApplication {

	public static void main(String[] args) throws IOException, SOAPException, ParserConfigurationException, JAXBException {

		SpringApplication.run(EdbAtfSoapClientApplication.class, args);
		JAXBContext jaxbContext = JAXBContext.newInstance(CelsiusToFahrenheit.class);
		System.out.println("jaxbContext is=" +jaxbContext.toString());

		/*ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		JAXBContext jc = (JAXBContext) JAXBContext.newInstance("https.www_w3schools_com.xml",classLoader);
		System.out.println("Brut check #1");*/
//		DynamicJAXBContext dynamicJAXBContext = (DynamicJAXBContext) JAXBContext.newInstance("https.www_w3schools_com.xml");
//		DynamicEntity celsius = dynamicJAXBContext.newDynamicEntity("https.www_w3schools_com.xml.CelsiusToFahrenheit");

		celsius.set("Celsius","200");


//		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
//		Marshaller marshaller = JAXBContext.newInstance().createMarshaller();
//		marshaller.marshal(celsius, document);

//		SOAPMessage soapMessage = MessageFactory.newInstance().createMessage();
//		soapMessage.getSOAPBody().addDocument(document);
//		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//		soapMessage.writeTo(outputStream);
//		String output = new String(outputStream.toByteArray());
//		System.out.print(output);

	}

}

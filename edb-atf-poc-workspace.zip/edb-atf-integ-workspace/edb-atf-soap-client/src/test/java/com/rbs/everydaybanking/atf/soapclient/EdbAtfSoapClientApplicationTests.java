package com.rbs.everydaybanking.atf.soapclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdbAtfSoapClientApplicationTests {

	@Test
	void contextLoads() {
	}

}

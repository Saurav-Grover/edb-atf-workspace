package com.everydaybanking.rbsg.edbatfsoapclientpoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdbAtfSoapClientPocApplicationTests {

	@Test
	void contextLoads() {
	}

}

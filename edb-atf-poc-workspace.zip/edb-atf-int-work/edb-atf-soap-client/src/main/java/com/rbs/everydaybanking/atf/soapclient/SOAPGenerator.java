package com.rbs.everydaybanking.atf.soapclient;


import javax.xml.bind.*;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import https.www_w3schools_com.xml.ObjectFactory;
import org.eclipse.persistence.dynamic.DynamicEntity;
import org.eclipse.persistence.internal.oxm.Root;
import org.eclipse.persistence.jaxb.dynamic.DynamicJAXBContext;
import org.eclipse.persistence.jaxb.dynamic.DynamicJAXBContextFactory;
import org.w3c.dom.Document;
import org.xml.sax.SAXParseException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class SOAPGenerator {

    public SOAPGenerator() throws ParserConfigurationException, JAXBException, SAXParseException {

        // Get the BlockFactory
       /* JAXBBlockFactory f = (JAXBBlockFactory)
                FactoryRegistry.getFactory(JAXBBlockFactory.class);*/

       /* // Create a jaxb object
        ObjectFactory factory = new ObjectFactory();
        EchoString jaxb = factory.createEchoString();
        jaxb.setInput("Hello World");
        JAXBBlockContext context = new JAXBBlockContext(EchoString.class.getPackage().getName());

        JAXBIntrospector jbi = JAXBUtils.getJAXBIntrospector(context.getJAXBContext());
        QName expectedQName = jbi.getElementName(jaxb);

        // Create a Block using the sample string as the content.  This simulates
        // what occurs on the outbound JAX-WS dispatch<JAXB> client
        Block block = f.createFrom(jaxb, context, null);

        // JAXB objects set the qname from their internal data
        assertTrue(block.isQNameAvailable());

        // Assume that we need to find the QName (perhaps to identify the operation and
        // determine if handlers are installed).   This is not very perfomant since
        // it causes an underlying parse of the String...but we need to support this.
        QName qName = block.getQName();
        assertTrue("Expected: " + expectedQName + " but found: " + qName, expectedQName.equals(qName));

        // Assuming no handlers are installed, the next thing that will happen
        // is a XMLStreamReader will be requested...to go to OM.   At this point the
        // block should be consumed.
        XMLStreamReader reader = block.getXMLStreamReader(true);

        // The block should be consumed
        assertTrue(block.isConsumed());

        // To check that the output is correct, get the String contents of the
        // reader
        Reader2Writer r2w = new Reader2Writer(reader);
        String newText = r2w.getAsString();
        assertTrue(newText.contains("Hello World"));
        assertTrue(newText.contains("echoString"));*/
    }

    public static void main(String[] args) throws SAXParseException, JAXBException, ParserConfigurationException, IOException {
        SOAPGenerator gen = new SOAPGenerator();
    }
}

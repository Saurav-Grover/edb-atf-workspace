package com.rbs.everydaybanking.atf.soapclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdbAtfSoapClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdbAtfSoapClientApplication.class, args);
	}

}

package stepdefs;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Test1 {

    @When("response code is {string}")
    public void response_code_is(String string) {
        System.out.println("Response code is : " +string);

    }

    @Then("response is success")
    public void response_is_success() {
        System.out.println("  We have got success");
    }

}

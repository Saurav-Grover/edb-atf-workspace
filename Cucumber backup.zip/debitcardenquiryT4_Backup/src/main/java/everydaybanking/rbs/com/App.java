package everydaybanking.rbs.com;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:success.feature",
        glue = "classpath:stepdefs"
)
public class App 
{
/*    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }*/
}

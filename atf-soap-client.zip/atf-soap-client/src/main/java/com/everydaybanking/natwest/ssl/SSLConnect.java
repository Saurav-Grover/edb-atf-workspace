package com.everydaybanking.natwest.ssl;

import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

@Configuration
public class SSLConnect {

    static {
        SSLUtilities.trustAllHostnames();
    }

    public SSLSocketFactory factory;

    SSLConnect() throws IOException, NoSuchAlgorithmException, KeyStoreException, CertificateException, UnrecoverableKeyException, KeyManagementException {

        /*
         * Set up a key manager for client authentication
         * if asked by the server.  Use the implementation's
         * default TrustStore and secureRandom routines.
         */
        final SSLContext ctx;
        final KeyManagerFactory kmf;
        final TrustManagerFactory tmf;
        final KeyStore tm;
        final KeyStore ks;
        final String trustStore = "src/main/resources/jks/trustStore";
        final String keystore = "src/main/resources/jks/monclient.jks";

        final char[] password = "iw@Bankside2".toCharArray();

        ctx = SSLContext.getInstance("TLS");

        tmf = TrustManagerFactory.getInstance("SunX509");
        kmf = KeyManagerFactory.getInstance("SunX509");

        tm = KeyStore.getInstance("JKS");
        ks = KeyStore.getInstance("JKS");

        tm.load(new FileInputStream(trustStore), password);
        ks.load(new FileInputStream(keystore), password);

        kmf.init(ks, password);
        tmf.init(tm);
        ctx.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

        this.factory = ctx.getSocketFactory();
        HttpsURLConnection.setDefaultSSLSocketFactory(this.factory);
    }
}

package com.everydaybanking.natwest.soap;

import com.everydaybanking.natwest.bean.JavaClassLoader;
import com.everydaybanking.natwest.ssl.SSLConnect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpUrlConnection;

import java.util.List;

public class SoapClient extends WebServiceGatewaySupport {

    private static final Logger log = LoggerFactory.getLogger(SoapClient.class);
    @Autowired
    private JavaClassLoader loader;
    @Autowired
    private SSLConnect sslConnect;

    public Object getServiceResponse(final Object clientReq, String host, int port, String operatingBrand, String endpointUri) {

        String endpointUrl = "https://" + host + ":" + port + "/" + operatingBrand + "/" + endpointUri;
        final Object response = this.getWebServiceTemplate().marshalSendAndReceive(endpointUrl, clientReq);
        return response;
    }

    public Object getServiceResponse(final Object clientReq, String host, int port, String operatingBrand, String endpointUri,String accessToken) {

        String endpointUrl = "https://" + host + ":" + port + "/" + operatingBrand + "/" + endpointUri;
        final Object response = this.getWebServiceTemplate().marshalSendAndReceive(endpointUrl, clientReq, new WebServiceMessageCallback() {
            @Override
            public void doWithMessage(WebServiceMessage webServiceMessage) {
                TransportContext context = TransportContextHolder.getTransportContext();
                HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
                connection.getConnection().addRequestProperty("Authorization",
                        accessToken);
                try {
                    connection.getConnection().addRequestProperty("primaryCin",
                            String.valueOf(loader.getParams(clientReq, "customerId")));
                } catch (Exception e) {}
            }});
        return response;
    }

    public Object createRequest(List<String> tagNames, List<String> tagValues, Object reqObj) {

        for (int i = 0; i < tagNames.size(); i++) {
            loader.setParams(reqObj, tagNames.get(i), tagValues.get(i));
        }
        return reqObj;
    }

}

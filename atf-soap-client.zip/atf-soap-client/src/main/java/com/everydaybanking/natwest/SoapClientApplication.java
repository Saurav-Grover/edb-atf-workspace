package com.everydaybanking.natwest;

import com.everydaybanking.natwest.soap.SoapClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.everydaybanking.natwest.*")
public class SoapClientApplication {

    private SoapClient soapClient;

    public static void main(final String[] args) {

//        System.setProperty("javax.net.debug","all");

        SpringApplication.run(SoapClientApplication.class, args);

    }

    /*@Bean
    CommandLineRunner lookup(final SoapClient soapClient) {
        return args -> {
            Object clientReq = soapClient.createRequest();

            if (args.length > 0) {
                clientReq = args[0];
            }
            final Object response = soapClient.getServiceResponse(clientReq);
        };
    }*/
}
package com.everydaybanking.natwest.bean;

import org.springframework.stereotype.Service;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * @author grovesq
 */

@Service
public class JavaClassLoader extends ClassLoader {

    public Object loadJaxBClass(final String className) {

        Object myClassObject = null;

        try {

            // Create a new JavaClassLoader
            final ClassLoader classLoader = getClass().getClassLoader();

            // Load the target class using its binary name
            final Class loadedMyClass = classLoader.loadClass("com.everydaybanking.natwest.wsdl." + className);

            // Create a new instance from the loaded class
            final Constructor constructor = loadedMyClass.getConstructor();
            myClassObject = constructor.newInstance();

        } catch (final ClassNotFoundException e) {
            e.printStackTrace();
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return myClassObject;
    }

    public Object loadJaxBClass(String serviceName,String className) {

        Object myClassObject = null;

        try {

            // Create a new JavaClassLoader
            final ClassLoader classLoader = getClass().getClassLoader();

            // Load the target class using its binary name
            final Class loadedMyClass = classLoader.loadClass("com.everydaybanking.natwest.wsdl." +serviceName+"."+ className);

            // Create a new instance from the loaded class
            final Constructor constructor = loadedMyClass.getConstructor();
            myClassObject = constructor.newInstance();

        } catch (final ClassNotFoundException e) {
            e.printStackTrace();
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return myClassObject;
    }


    public void setParams(Object object, String property, Object value) {
        try {
            final Class clazz = object.getClass();
            final Field field = clazz.getDeclaredField(property);

            if ("long".equalsIgnoreCase(String.valueOf(field.getType()))) {
                field.setAccessible(true);
                final long obj = Long.parseLong(String.valueOf(value));
                field.set(object, obj);
            } else {
                field.setAccessible(true);
                field.set(object, value);
            }
        } catch (Exception e){
        }
    }

    public Object getParams(Object Obj, String property) throws IllegalAccessException, NoSuchFieldException {
        final Field field1 = Obj.getClass().getDeclaredField(property);
        field1.setAccessible(true);
        final Object fieldValue = field1.get(Obj);
        return fieldValue;
    }

}

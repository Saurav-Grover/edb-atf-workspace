package com.everydaybanking.natwest.stepdefs;

import com.everydaybanking.natwest.bean.JavaClassLoader;
import com.everydaybanking.natwest.soap.SoapClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import java.util.List;

public class CommonConfigBean{

    @Autowired
    private JavaClassLoader cld;

    @Autowired
    private SoapClient client;

    private String accessToken;

    private String serviceName;

    private Jaxb2Marshaller marshaller;

    private static Object reqObj, resObj;

    private List<String> tagNames, tagvalues;

    static {
        reqObj = new Object();
        resObj = new Object();
    }

    public static final String srcPackage = "com.everydaybanking.natwest.wsdl.";

    public JavaClassLoader getCld() {
        return this.cld;
    }

    public void setCld(final JavaClassLoader cld) {
        this.cld = cld;
    }

    public SoapClient getClient() {
        return this.client;
    }

    @Bean
    public void setClient(String serviceName) {
        setMarshaller(serviceName);
        client.setMarshaller(getMarshaller());
        client.setUnmarshaller(getMarshaller());
    }

    public Jaxb2Marshaller getMarshaller() {
        return this.marshaller;
    }

    public void setMarshaller(String serviceName) {
        setServiceName(serviceName);
        marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(srcPackage + getServiceName());
    }

    public String getServiceName() {
        return this.serviceName;
    }

    public void setServiceName(final String serviceName) {
        this.serviceName = serviceName;
    }

    public Object getReqObj() {
        return this.reqObj;
    }

    public void setReqObj(final Object reqObj) {
        this.reqObj = reqObj;
    }

    public Object getResObj() {
        return this.resObj;
    }

    public void setResObj(final Object resObj) {
        this.resObj = resObj;
    }

    public List<String> getTagNames() {
        return this.tagNames;
    }

    public void setTagNames(final List<String> tagNames) {
        this.tagNames = tagNames;
    }

    public List<String> getTagvalues() {
        return this.tagvalues;
    }

    public void setTagvalues(final List<String> tagvalues) {
        this.tagvalues = tagvalues;
    }

    public String getAccessToken() {
        return this.accessToken;
    }

    public void setAccessToken(final String accessToken) {
        this.accessToken = accessToken;
    }
}
package com.everydaybanking.natwest.stepdefs;

import com.everydaybanking.natwest.StepDefsException;
import com.everydaybanking.natwest.soap.SoapClient;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.ComparisonFailure;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

public class Stepdefs extends CommonConfigBean {

    private static Map<Long, Object> enquiryResObjects;

    @Given("service name is {string}")
    public void service_name_is(String serviceName) {
        new CommonConfigBean();
        setClient(serviceName);
    }

    @Given("operations to perform are {string} and {string}")
    public void operations_to_perform_are_and(String requestOpr, String responseOpr) {

        setReqObj(getCld().loadJaxBClass(getServiceName(), requestOpr));
        setResObj(getCld().loadJaxBClass(getServiceName(), responseOpr));
    }

    @When("customer Data table is provided")
    public void customer_Data_table_is_provided(io.cucumber.datatable.DataTable dataTable) {
        // Write code here that turns the phrase above into concrete actions
        // For automatic transformation, change DataTable to one of
        // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
        // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
        // Double, Byte, Short, Long, BigInteger or BigDecimal.
        // For other transformations you can register a DataTableType.
        setTagNames(dataTable.row(0));
        setTagvalues(dataTable.row(1));
    }

    @Then("create request based upon data table")
    public void create_request_based_upon_data_table() {
        try {
            SoapClient client = getClient();
            setReqObj(client.createRequest(getTagNames(), getTagvalues(), getReqObj()));
        } catch (Exception e) {
        }
    }

    @Then("call backend with {string}, {int} and {string}")
    public void call_backend_with_and_(String host, Integer port, String uri) {
        try {
            String operatingBrand = (String) getCld().getParams(getReqObj(), "operatingBrand");
            if(getAccessToken()==null)
            setResObj(getClient().getServiceResponse(getReqObj(), host, port, operatingBrand, uri));
            else {
                setResObj(getClient().getServiceResponse(getReqObj(), host, port, operatingBrand, uri, getAccessToken()));
            }
        } catch (Exception e) {
        }
    }


    @Then("verify {string} value {string} and initialize data in context")
    public void verify_value_and_initialize_data_in_context(String field, String expected) throws StepDefsException {
        try {
            assertEquals(expected, String.valueOf(getCld().getParams(getResObj(), field)));
        } catch (Exception e) {
            throw new StepDefsException("\n\n\t\t\tFailure: " + field + " values is other than " + expected+"\n");
        }catch (ComparisonFailure e) {
            throw new StepDefsException("\n\n\t\t\tFailure: " + field + " values is other than " + expected+"\n");
        }
    }

    @Given("enquire debit cards from {string}, {int} and {string}")
    public void enquire_debit_cards_from_and(String host, Integer port, String uri, io.cucumber.datatable.DataTable dataTable) {

        setTagNames(dataTable.row(0));
        setTagvalues(dataTable.row(1));
        try {
            create_request_based_upon_data_table();
            Long customerId = (Long) getCld().getParams(getReqObj(), "customerId");
            String operatingBrand = (String) getCld().getParams(getReqObj(), "operatingBrand");
            enquiryResObjects = new HashMap<>();
            List<Object> cardDetailsArray = null;
            setResObj(getClient().getServiceResponse(getReqObj(), host, port, operatingBrand, uri));
            cardDetailsArray = (List<Object>) getCld().getParams(getResObj(), "cardDetailsArray");

            if (cardDetailsArray.size() > 0)
                for (Object card : cardDetailsArray)
                    enquiryResObjects.put(customerId, card);
            else
                throw new StepDefsException("Call not processed : Unable to find any valid vtcDocumentId for customer : " + customerId);

        } catch (Exception e) {
        }
    }
    @Given("ATUToken details from {string}, {int} and {string}")
    public void atutoken_details_from_and(String host, Integer port, String uri, io.cucumber.datatable.DataTable dataTable) {
        setTagNames(dataTable.row(0));
        setTagvalues(dataTable.row(1));
        try {
            create_request_based_upon_data_table();
            Long customerId = (Long) getCld().getParams(getReqObj(), "customerId");
            String brand = (String) getCld().getParams(getReqObj(), "brand");
            System.out.println("Inside ATU Token execution :" + getResObj().getClass().toString() + "  Customer Id : " + customerId);
            if (customerId > 0 || brand != null) {
                setResObj(getClient().getServiceResponse(getReqObj(), host, port, brand, uri));
                setAccessToken((((String) getCld().getParams(getResObj(), "accessToken"))).split("\"")[5]);
            } else {
                throw new StepDefsException("Call not processed : Unable to validate customer details");
            }
        } catch (Exception e) {
        }

    }

    @Then("create request with {string}")
    public void create_request_with(String tagName) throws StepDefsException {
        if (enquiryResObjects.size() > 0) {
            try {
                create_request_based_upon_data_table();
                Iterator itr = enquiryResObjects.entrySet().iterator();
                while (itr.hasNext()) {
                    Map.Entry entry = (Map.Entry) itr.next();
                    Object cardDetail = entry.getValue();
                    String tagValue = (String) getCld().getParams(cardDetail, tagName);
                    if (tagName != null) {
                        getCld().setParams(getReqObj(), tagName, tagValue);
                    }
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        } else {
            throw new StepDefsException("No " + tagName + " is associated with card");
        }
    }

    /*For testing purpose*/

    public static String printObjectXml(Object o) throws Exception {
        System.out.println("-------------------");
        StringWriter sw = new StringWriter();
        JAXBContext jaxbContext = JAXBContext.newInstance(o.getClass());
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        jaxbMarshaller.marshal(o, System.out);
        jaxbMarshaller.marshal(o, sw);

        return sw.toString();
    }
}
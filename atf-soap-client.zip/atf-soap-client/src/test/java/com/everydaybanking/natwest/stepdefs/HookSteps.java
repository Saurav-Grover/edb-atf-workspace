package com.everydaybanking.natwest.stepdefs;

import io.cucumber.java.Before;

public class HookSteps extends  CommonConfigBean {

    /*Enquiry to call Enquiry service before actual service*/
    @Before(value = "@EnquireFlag")
    public void EnquireFlag() {
        setClient("EDBDebitCardEnquiry");
        setReqObj(getCld().loadJaxBClass("EDBDebitCardEnquiry", "GetDebitCardsForCustReq"));
        setResObj(getCld().loadJaxBClass("EDBDebitCardEnquiry", "GetDebitCardsForCustRes"));
    }

    @Before(value = "@ATUTokenFlag")
    public void ATUTokenFlag(){
        setClient("RBSGCreateATUToken");
        setReqObj(getCld().loadJaxBClass("RBSGCreateATUToken", "CreateATUTokenRequest"));
        setResObj(getCld().loadJaxBClass("RBSGCreateATUToken", "CreateATUTokenResponse"));
    }
}

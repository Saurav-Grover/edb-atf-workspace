package com.everydaybanking.natwest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = CucumberTests.class)
public class SoapClientApplicationTests {

    @Test
    void contextLoads(){
    }

}

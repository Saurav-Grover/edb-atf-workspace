package com.everydaybanking.natwest;

public class StepDefsException extends  Exception {

    public StepDefsException(String msg){
        super(msg);
    }
}

package everydaybank.rbs.com;


import org.apache.poi.ss.usermodel.Sheet;

import javax.xml.soap.*;
import java.io.IOException;
import java.util.*;

public class SOAPAPICallerType2 {

    // SAAJ - SOAP Client Testing
    /*public static void main(String args[]) {

        String soapEndpointUrl = "https://www.w3schools.com/xml/tempconvert.asmx";
        String soapAction = "https://www.w3schools.com/xml/CelsiusToFahrenheit";

        callSoapWebService(soapEndpointUrl, soapAction);
    }*/

    static List<SOAPMessage> listOfMessages = new ArrayList<SOAPMessage>();
    static List<SOAPMessage> responseMessages = new ArrayList<SOAPMessage>();

    private static void createSoapEnvelope(SOAPMessage soapMessage) throws SOAPException {
        SOAPPart soapPart = soapMessage.getSOAPPart();

        String myNamespace = "myNamespace";
        String myNamespaceURI = "https://www.w3schools.com/xml/";

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration(myNamespace, myNamespaceURI);

        // SOAP Body
        SOAPBody soapBody = envelope.getBody();
        SOAPElement soapBodyElem = soapBody.addChildElement("CelsiusToFahrenheit", myNamespace);
        SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("Celsius", myNamespace);
        soapBodyElem1.addTextNode("100");
    }

    public static void celciusToFahrenheitData(SOAPMessage soapMessage, Double data) throws SOAPException {

            SOAPPart soapPart = soapMessage.getSOAPPart();
            String myNamespace = "myNamespace";
            String myNamespaceURI = "https://www.w3schools.com/xml/";

            // SOAP Envelope
            SOAPEnvelope envelope = soapPart.getEnvelope();
            envelope.addNamespaceDeclaration(myNamespace, myNamespaceURI);

            // SOAP Body
            SOAPBody soapBody = envelope.getBody();
            SOAPElement soapBodyElem = soapBody.addChildElement("CelsiusToFahrenheit", myNamespace);
            SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("Celsius", myNamespace);
            soapBodyElem1.addTextNode(String.valueOf(data));
            soapMessage.saveChanges();

            listOfMessages.add(soapMessage);
    }

    public static void callSoapWebService(String soapEndpointUrl, String soapAction, List<Double> data) {
        try {
            // Create SOAP Connection
            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
            SOAPConnection soapConnection = soapConnectionFactory.createConnection();

//            System.out.println("SoapAction : "+soapAction+"   dataLength"+data);

            List<SOAPMessage> soapMessages = createSOAPRequest(soapAction,data);

            Iterator itr = soapMessages.iterator();

            while(itr.hasNext()){
                // Send SOAP Message to SOAP Server
                SOAPMessage soapResponse = soapConnection.call((SOAPMessage) itr.next(),soapEndpointUrl);
                // Print the SOAP Response
//                System.out.println("Response SOAP Message:");
//                soapResponse.writeTo(System.out);
                responseMessages.add(soapResponse);
//                System.out.println();
            }

            writeResults(listOfMessages,responseMessages);

            soapConnection.close();
        } catch (Exception e) {
            System.err.println("\nError occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
            e.printStackTrace();
        }
    }

    private static List<SOAPMessage> createSOAPRequest(String soapAction, List<Double> data) throws Exception {

        Iterator itr = data.iterator();
        while (itr.hasNext()) {
            MessageFactory messageFactory = MessageFactory.newInstance();
            SOAPMessage soapMessage = messageFactory.createMessage();

            MimeHeaders headers = soapMessage.getMimeHeaders();
            headers.addHeader("SOAPAction", soapAction);
            celciusToFahrenheitData(soapMessage, (Double) itr.next());
        }

        SOAPMessage msg = null;
        System.out.println("Request message in List are : "+listOfMessages.size());

        Iterator soapData = listOfMessages.iterator();

        /* Print the request message, just for debugging purposes */
//        while (soapData.hasNext()) {
//            System.out.println("Request SOAP Message:");
//            msg = (SOAPMessage) soapData.next();
//            msg.writeTo(System.out);
//            System.out.println("\n");
//        }

        return listOfMessages;
    }


    public static void writeResults(List<SOAPMessage> requestMessages, List<SOAPMessage> responseMessages) throws IOException, SOAPException {

        ReadExcelAndMakeCall call = new ReadExcelAndMakeCall();
        call.resultWriter(requestMessages,responseMessages);
    }

}
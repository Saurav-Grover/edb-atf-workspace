package everydaybank.rbs.com;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

public class ReadExcelAndMakeCall {

    public Sheet xlsxReader(int sheetIndex) {
        XSSFSheet sheet = null ;

        try {
            File file = new File("C:/Users/saurav.grover/IdeaProjects/soapCall/src/main/java/everydaybank/rbs/com/CelciusToFarenhite.xlsx");
            FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
            //creating Workbook instance that refers to .xlsx file
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            sheet = wb.getSheetAt(sheetIndex);     //creating a Sheet object to retrieve object

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sheet;
    }

    public List<Double> readDataToArray(Sheet sheet){


        List<Double> testData = new ArrayList<Double>();

        Iterator<Row> itr = sheet.iterator();    //iterating over excel file
        while (itr.hasNext()) {
            Row row = itr.next();
            Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case STRING:    //field that represents string cell type
//                        System.out.print(cell.getStringCellValue() + "\t\t\t");
                        break;
                    case NUMERIC:    //field that represents number cell type
                        testData.add(cell.getNumericCellValue());
                        break;
                    default:
                        break;
                }
            }
        }
        return testData;

    }

    public void resultWriter(List<SOAPMessage> requestMessages, List<SOAPMessage> responseMessages) throws IOException, SOAPException {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("results");

        Row heading = sheet.createRow(0);
        heading.createCell(0).setCellValue("Request");
        heading.createCell(1).setCellValue("Response");

        int reqRowIndex = 1;
        Iterator reqItr = requestMessages.iterator();
        Iterator resItr = responseMessages.iterator();
        while (reqItr.hasNext() && resItr.hasNext()){
            SOAPMessage reqMessage = (SOAPMessage) reqItr.next();
            ByteArrayOutputStream out1 = new ByteArrayOutputStream();
            reqMessage.writeTo(out1);
            SOAPMessage resMessage = (SOAPMessage) resItr.next();
            ByteArrayOutputStream out2 = new ByteArrayOutputStream();
            resMessage.writeTo(out2);
            Row row = sheet.createRow(reqRowIndex++);
            row.createCell(0).setCellValue(new String(out1.toByteArray()));
            row.createCell(1).setCellValue(new String(out2.toByteArray()));
        }

        try {
            // this Writes the workbook gfgcontribute
            FileOutputStream out = new FileOutputStream(new File("resultsSheet.xlsx"));
            workbook.write(out);
            out.close();
            System.out.println("resultSheet.xlsx written successfully on disk.");
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    }

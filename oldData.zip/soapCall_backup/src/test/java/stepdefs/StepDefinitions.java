package stepdefs;

import everydaybank.rbs.com.ReadExcelAndMakeCall;
import everydaybank.rbs.com.SOAPAPICallerType2;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import java.util.ArrayList;
import java.util.List;

public class StepDefinitions {

    @When("url and namespace is provided")
    public void url_and_namespace_is_provided() {
        String soapEndpointUrl = null;
        String soapAction = null;

        ReadExcelAndMakeCall call = new ReadExcelAndMakeCall();
        Sheet sheet1 = call.xlsxReader(0);

        Row row = sheet1.getRow(1); //returns the logical row
        Cell url = row.getCell(0); //getting the cell representing the given column
        soapEndpointUrl = url.getStringCellValue();    //getting cell value  */
        Cell action = row.getCell(1);
        soapAction = action.getStringCellValue();

        /*System.out.println("URL : " + soapEndpointUrl + "  Action : " + soapAction);*/

        Sheet sheet2 = call.xlsxReader(1);

        List<Double> celciusToFahrenheitData = new ArrayList<Double>();

        celciusToFahrenheitData = call.readDataToArray(sheet2);

//        SOAPAPICallerType2 caller = new SOAPAPICallerType2();
        SOAPAPICallerType2.callSoapWebService(soapEndpointUrl, soapAction,celciusToFahrenheitData);
    }


    @Then("create SOAP request from data available in file")
    public void create_SOAP_request_from_data_available_in_file() {
        // Write code here that turns the phrase above into concrete actions
//        throw new io.cucumber.java.PendingException();
    }

}
